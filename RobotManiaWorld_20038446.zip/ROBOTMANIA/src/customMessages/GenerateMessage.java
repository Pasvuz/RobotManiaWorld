package customMessages;

import javax.swing.*;

@SuppressWarnings("serial")
public class GenerateMessage extends JDialog {

    public static final String ERROR = "error";
    public static final String INFO = "info";
    public static final String PLAIN = "plain";
    public static final String CONFIRMATION = "confirm";

    /**
     * Empty Constructor
     * Subclass of JDialog
     *
     * @view JDialog
     */
    public GenerateMessage() {
        super();
    }

    /**
     * GenerateMessage constructor with mex and notoriety
     * @param mex The text Generate Message will show
     * @param notoriety Identificates the problem of the text
     */
    public GenerateMessage(String mex, String notoriety) {
        this();
        mexGUI(mex, notoriety);
    }

    /**
     * If true, generate message of new game
     * @param gameInformation
     */
    public GenerateMessage(boolean gameInformation) {
        this();
        if (gameInformation)
            mexGUI("Welcome to RobotManiaWorld!\n\n" +
                    " -- Main --\n" +
                    "Button: Play, will generate a map, and game will start.\n" +
                    "You will see black and white cells, the black one is the wall, these cannot be trespassed, if so, a BUMP signal will be generated\n" +
                    "In the map you will see:\n   " +
                    " - Households\n" +
                    "           Households can break during the game, water will spread from them one turn at a time.\n" +
                    "           You can fix them only if Robot is watching them and clicking button \"Make Action\".\n    " +
                    " - Pet\n" +
                    "           Is not possible to interact with pet.\n" +
                    "Button: Change dimension for change size of grid.\n" +
                    "Button: Load game, if you already played, a File Chooser will generate and you will load the game\n\n" +
                    " -- JOYSTICK --\n" +
                    "Once game is stared through play button, a joystick will appear, it cannot be closed.\n" +
                    "You will see three arrow: one for turning left, one for going straight, one for turning right.\n" +
                    "You can interact with household only if robot is looking at them straight, otherwise a BUMP signal will be generated\n" +
                    "On your left you will see two different text:\n" +
                    "   - First one will give information about closer cell\n" +
                    "   - The second one will show you each BUMP signal generated\n" +
                    "If you need these information again, click on the button with the info icon.\n" +
                    "You can save the game by clicking on the next button, and load it on main menu before playing.\n\n" +
                    "Close this window for interact with main menu.", GenerateMessage.PLAIN);
    }

    private int mexGUI(String mex, String notoriety) {
        if(mex == null)
            mex = "";

        this.setAlwaysOnTop(true);
        this.setVisible(true);

        switch (notoriety) {
            case "info":
                JOptionPane.showMessageDialog(this, mex);
                break;

            case "error":
                JOptionPane.showMessageDialog(this, mex, "Action Prohibited", JOptionPane.ERROR_MESSAGE);
                break;

            case "plain":
                JOptionPane.showMessageDialog(this, mex, "Notification", JOptionPane.PLAIN_MESSAGE);
                break;

            case "confirm": {
                int option = JOptionPane.showConfirmDialog(this, "Are you sure?");

                if (option == JOptionPane.YES_OPTION)
                    return 1;
            }

            // in case notoriety is null or doesn't exist
            default: break;
        }

        return 0;
    }

    /**
     * If user wants to close game it ask him if he is sure about
     * @return integer, the choice of user
     */
    public int askConfirm()
    {
        return mexGUI("Are you sure to close the game?", GenerateMessage.CONFIRMATION);
    }
}

