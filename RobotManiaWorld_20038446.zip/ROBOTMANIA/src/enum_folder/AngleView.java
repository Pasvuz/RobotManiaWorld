package enum_folder;

public enum AngleView {
    UP(0),
    RIGHT(270),
    DOWN(180),
    LEFT(90);

    private final Integer value;

    /**
     * Manage the angle of Robot looking in 4 Direction each one is an integer value
     * @param value
     *
     * @view Robot
     */
    AngleView(int value) {
        this.value = value;
    }

    /**
     * return actual angle
     * @return
     */
    public Integer getValue() {
        return this.value;
    }

    /**
     * Returns AngleView angle of given number, if it exists
     * @param value Integer value of an angle (ex: 0, 180, 270, 360)
     * @return AngleView parameter
     */
    public static AngleView fromInteger(Integer value) {
        if(value == null)
            throw new IllegalArgumentException("Null argument");


        for (AngleView angleView : AngleView.values()) {
            if(value.equals(angleView.value))
                return angleView;
        }

        throw new NoSuchFieldError("No constant with number " + value + " found");
    }

}