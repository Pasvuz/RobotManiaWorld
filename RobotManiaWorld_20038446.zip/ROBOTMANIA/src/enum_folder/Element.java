package enum_folder;

/**
 * Element
 *
 * Water and Fire
 */
public enum Element
{
    WATER_SPREAD, FIRE_SPREAD
}
