package enum_folder;

/**
 * All the item can be in RobotManiaWorld
 */
public enum Items {
    EMPTY, ROBOT, STOVE, WALL, CAT, DOG, SINK, WASHING_MACHINE, WET
}
