package enum_folder;

/**
 * Directions for RobotManiaComponent
 *
 * @view RobotManiaComponent
 */
public enum Directions {
    UP, LEFT, RIGHT, DOWN, TURN_LEFT, TURN_RIGHT, NONE, ALL
}
