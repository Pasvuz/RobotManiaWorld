import static org.junit.jupiter.api.Assertions.*;

import javax.swing.Icon;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import enum_folder.Directions;
import enum_folder.Items;
import model.RobotManiaModel;
import view.JCell;

class TestModel {
	
	private RobotManiaModel model;
	

	@BeforeEach
	void setUp() {
		this.model = new RobotManiaModel();
	}
	
	@Test
	void testNegativeOrNeutralDimension() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			model.createMap(0,  true);
		}, "Nessuna eccezione per model.createMap() con una dimensione neutra");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			model.createMap(0,  false);
		}, "Nessuna eccezione per model.createMap() con una dimensione neutra");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			model.createMap(-1,  false);
		}, "Nessuna eccezione per model.createMap() con una dimensione negativa");
		
	}
	
	@Test
	void testNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			model.getBUMP(null);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			model.turnRobot(null);
		});
		
		
		Assertions.assertThrows(Exception.class, () ->
		{
			model.loadGame(null, 0);
		});

	}
	
	@Test
	void testCheckMap() 
	{
		Assertions.assertThrows(RuntimeException.class, () ->
		{
			/* 
			 * Sto chiedendo di creare un gioco, con un gioco caricato ( new_game == false), e il robot manca.
			 */
			
			model.play(40, false, false);
		});
		
		
		int dim = 4;
		
		model.createMap(dim, false);
		
		JCell[][] mappa = model.getMap();
		
		checkMap(dim, mappa);
		
		/* Part 2: Usando la funzione play() */
		
		dim = 15;
		try {
			model.play(dim, true, false);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "\n testCheckMap, qualcosa di sbagliato");
		}
		
		mappa = model.getMap();
		
		checkMap(dim, mappa);
	}
	
	@Test
	void testGetBUMP()
	{
		if (!model.getBUMP("").isEmpty())
			fail();

		Assertions.assertThrows(Exception.class, () -> {
			model.getBUMP(null).isEmpty();
		});
	}
	
	@Test
	void testTurnRobot()
	{
		try {
			model.play(7, true, false);
		} catch (Exception e) {
			System.out.println(e.getMessage() + "\n testTurnRobot, qualcosa di sbagliato");
		}
		
		JCell cellaRobot = findRobot(model.getMap());
		
		if(cellaRobot == null)
			fail("No robot detected, testTurnRobot");


		Assertions.assertThrows(Exception.class, () -> {
			model.turnRobot(Directions.ALL);
		});
		
		for(int i = 0; i < 4; i++)
		{
			Icon iconfirst = findRobot(model.getMap()).getIcon();
			
			try {
				model.turnRobot(Directions.TURN_LEFT);
			} catch (Exception e) {
				fail(e.getMessage());
			}

			Assertions.assertNotEquals(iconfirst, findRobot(model.getMap()).getIcon());
		}

		for(int i = 0; i < 4; i++)
		{
			Icon iconfirst = findRobot(model.getMap()).getIcon();

			try {
				model.turnRobot(Directions.TURN_RIGHT);
			} catch (Exception e) {
				fail(e.getMessage());
			}

			Assertions.assertNotEquals(iconfirst, findRobot(model.getMap()).getIcon());
		}
	}
	
	@Test
	void testMapOrRobotIsNull()
	{
		Assertions.assertThrows(Exception.class, () ->{
			model.makeAction();
		});
		
		Assertions.assertThrows(Exception.class, () ->{
			model.turnRobot(null);
		});
		
		Assertions.assertThrows(Exception.class, () ->{
			model.getMap();
		});
		
		Assertions.assertThrows(Exception.class, () ->{
			model.getNeighbours();
		});
		
		Assertions.assertThrows(Exception.class, () ->{
			model.makeAction();
		});
		
		Assertions.assertThrows(Exception.class, () ->{
			model.removeFogOfWar(0,0); // è un muro
		});
		
		Assertions.assertThrows(Exception.class, () ->{
			model.saveGame();
		});
	}

	private JCell findRobot(JCell[][] map) {
		for(JCell[] rows : map)
			for(JCell cella : rows)
			{
				if(cella.getItem().equals(Items.ROBOT))
					return cella;
			}
		
		return null;
	}

	private void checkMap(int dim, JCell[][] mappa)
	{
		for(JCell[] rows : mappa)
			for(JCell cella : rows)
			{
				if(cella == null)
					fail("cella nulla ");
				
				if(cella.getPositionX() == 0 || cella.getPositionX() == dim - 1 || cella.getPositionY() == 0 || cella.getPositionY() == dim - 1)
				{
					if(!(cella.getItem().equals(Items.WALL)))
						fail("Cella non è un muro");
				}
			}
	}
}