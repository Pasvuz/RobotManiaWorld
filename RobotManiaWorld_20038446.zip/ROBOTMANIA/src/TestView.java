import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import view.ControlView;
import view.RobotManiaView;

class TestView {
	private static RobotManiaView view;
	
	@BeforeEach
	void setUp()
	{
		view = new RobotManiaView();
		Assertions.assertNotNull(view);
	}
	
	@Test
	void testControlloNonNulli() {
		Assertions.assertNotNull(view.getControlView());
		Assertions.assertNotNull(view.getDimension());
		Assertions.assertNotNull(view.getView());
	}
	
	@Test
	void testControlView()
	{
		ControlView controlView = view.getControlView();
		view.closeControlView();
		Assertions.assertEquals(controlView, view.getControlView());
	}

	@AfterAll
	static void close()
	{
		view.close();
	}

}
