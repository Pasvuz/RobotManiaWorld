package model;

import components.RobotManiaComponentAlive;
import components.RobotManiaComponentNotAlive;
import components.RobotManiaWorldComponent;
import components.pet.Cat;
import components.pet.Dog;
import components.robot.Robot;
import components.waterFire_Element.*;
import enum_folder.Directions;
import enum_folder.Element;
import enum_folder.Items;
import view.JCell;

import java.util.*;

public class RobotManiaModel
{
    public static final String MOVE = "move";
    public static final String ACTION = "action";

    private final ModelPlay modelPlay;
    private Robot robot;
    private JCell[][] map;

    /**
     * RobotManiaModel the model of RobotManiaWorld
     */
    public RobotManiaModel()
    {
        this.modelPlay = new ModelPlay();
        dimension = 0;
    }

    private static int dimension;
    private boolean fogOfWar;

    /* Inner Class */
    protected static class ModelPlay
    {
        private final ArrayList<RobotManiaComponentAlive> componentsAlive;
        private final ArrayList<RobotManiaComponentNotAlive> componentsNotAlive;
        private final ArrayList<Set<Water>> componentWater;

        private final ArrayList<RobotManiaWorldComponent> listComponents;

        protected ModelPlay()
        {
            this.componentsAlive = new ArrayList<>();
            this.componentsNotAlive = new ArrayList<>();
            this.listComponents = new ArrayList<>();
            this.componentWater = new ArrayList<>();
        }

        /* GETTER */
        protected ArrayList<RobotManiaWorldComponent> getListComponents()
        {
            // for refreshing
            listComponents.clear();

            listComponents.addAll(componentsNotAlive);
            listComponents.addAll(componentsAlive);


            return this.listComponents;
        }

        protected ArrayList<RobotManiaComponentAlive> getComponentsAlive() {
            return componentsAlive;
        }
        protected ArrayList<RobotManiaComponentNotAlive> getComponentsNotAlive() {
            return componentsNotAlive;
        }

        protected HashSet<Water> getComponentWater(int index) {
            if(index < 0 || index >= componentWater.size())
                throw new ArrayIndexOutOfBoundsException("Given index is negative or higher than array size");

            return (HashSet<Water>) componentWater.get(index);
        }

        protected void addComponent( int x, int y, Items item, int index, boolean status)
        {
            switch(item)
            {
                case ROBOT:
                {
                    Robot robot = new Robot();
                    robot.setPosition(x, y);
                    componentsAlive.add(robot);
                    break;
                }

                case CAT:
                {
                    Cat cat = new Cat();
                    cat.setPosition(x,y);
                    componentsAlive.add(cat);
                    break;
                }

                case DOG:
                {
                    Dog dog = new Dog();
                    dog.setPosition(x,y);

                    componentsAlive.add(dog);
                    break;
                }

                case SINK:
                {
                    Sink sink = new Sink(index);
                    assignProperty(sink, x, y, status);

                    componentsNotAlive.add(sink);
                    break;
                }

                case STOVE:
                {
                    Stove stove = new Stove(index);
                    assignProperty(stove, x, y, status);

                    componentsNotAlive.add(stove);
                    break;
                }

                case WASHING_MACHINE:
                {
                    WashingMachine wm = new WashingMachine(index);
                    assignProperty(wm, x, y, status);

                    componentsNotAlive.add(wm);
                    break;
                }

                default:
                    break;
            }
        }

        private void assignProperty(RobotManiaComponentNotAlive componentNotAlive, int x, int y, boolean status)
        {
            componentNotAlive.setStatus(status);
            componentNotAlive.setImageIcon(componentNotAlive.getPair(status));
            componentNotAlive.setPosition(x,y);
        }

        ////////////////////////////////////////////////////////////////////////////
        protected void spawnComponents(int dimension)
        {
            // robot
            create(1, true, true);  // alive and special -> is player

            // pets
            int maxPets = (int) Math.round((Math.random() * dimension / 2));
            int how_many = (int) Math.round(1 + (Math.random() * maxPets));
            create(how_many, true, false); // true: alive

            // household appliance
            int maxHouseHold = (int) Math.round((Math.random() * dimension / 2) + 5);
            how_many = (int) Math.round(1 + (Math.random() * maxHouseHold));
            create(how_many, false, false); // false: not alive

        }

        private void create(int how_many_item, boolean id, boolean special)
        {
            if(special)
                this.componentsAlive.add(new Robot());
            else
            {
                if(id)
                {
                    for(int i = 0; i < how_many_item; i++)
                    {
                        if(i % 2 == 0)
                            this.componentsAlive.add(new Cat());
                        else
                            this.componentsAlive.add(new Dog());
                    }
                }
                else
                {
                    int i = 0;

                    while(true)
                    {
                        this.componentsNotAlive.add(new Stove(i));
                        i++;
                        if(i == how_many_item)
                            break;

                        this.componentsNotAlive.add(new WashingMachine(i));
                        i++;
                        if(i == how_many_item)
                            break;

                        this.componentsNotAlive.add(new Sink(i));

                        i++;
                        if(i == how_many_item)
                            break;
                    }
                }
            }
        }

        protected Robot getRobot() throws RuntimeException {
            for(RobotManiaComponentAlive componentAlive : componentsAlive)
            {
                if(componentAlive.getItem().equals(Items.ROBOT))
                    return (Robot) componentAlive;
            }

            throw new RuntimeException("No robot detected");
        }

        protected void addElementWater(int x, int y, int index) throws ArrayIndexOutOfBoundsException
        {
            if(x == 0 || x == dimension || y == 0 || y == dimension)
                return;

            checkWaterIndex(index);

            Water water = new Water(x, y);

            if (componentWater.get(index).isEmpty())
                this.componentWater.get(index).add(water);
            else
            {
                Set<Water> arr = new HashSet<>(componentWater.get(index));

                for (Water water1 : arr) {
                    if (water1.getPositionX() != x || water1.getPositionY() != y) {
                        this.componentWater.get(index).add(water);
                        return;
                    }
                }
            }
        }

        protected void clearWaterArray(int indexCounter)
        {
            checkWaterIndex(indexCounter);

            if(indexCounter < 0 || indexCounter >= componentWater.size())
                throw new IndexOutOfBoundsException("Index out of array size or negative");

            componentWater.get(indexCounter).clear();
        }

        protected void initializeWaterArray()
        {
            for(int i = 0; i < componentsNotAlive.size(); i++)
                componentWater.add(new HashSet<>());
        }

        protected boolean containsWater(int x, int y, int index)
        {
            checkWaterIndex(index);

            for(SpreadableElement spreadableElement : componentWater.get(index))
                if(spreadableElement.getPositionX() == x && spreadableElement.getPositionY() == y)
                    return true;

            return false;
        }

        protected int componentWaterSize()
        {
            return componentWater.size();
        }

        protected boolean isValidFile(String readFile, int countLines) throws Exception {
            String separator = "SECOND_PART\n";

            if(countLines <= 0 || readFile == null)
                throw new IllegalArgumentException("File doesn't exist");

            if(readFile.isEmpty())
                throw new IllegalArgumentException("File is empty");

            if(!readFile.contains(separator))
                return false;

            String[] strings = readFile.split(separator);
            /* Removing any space */
            if(strings[0] != null)
                if(strings[0].isEmpty())
                    return false;
                else
                    strings[0] = strings[0].trim();
            else
                return false;

            ArrayList<Items> list = new ArrayList<>();

            Scanner scanner = new Scanner(strings[0]);

            Integer.parseInt(String.valueOf(scanner.nextInt()));

            checkBoolean(scanner.next());

            while(scanner.hasNextLine())
            {
                Integer.parseInt(String.valueOf(scanner.nextInt()));
                Integer.parseInt(String.valueOf(scanner.nextInt()));

                Items item = checkItem(scanner.next());
                list.add(item);

                checkBoolean(scanner.next());
                checkBoolean(scanner.next());
            }
            scanner.close();

            if(!list.contains(Items.ROBOT))
                throw new Exception("No robot detected in file, impossible load this file");
            else {
                if (list.indexOf(Items.ROBOT) != list.lastIndexOf(Items.ROBOT))
                    throw new Exception("Two robot or more ROBOT detected in file");
            }

            if(list.contains(Items.SINK) || list.contains(Items.WASHING_MACHINE))
            {
                if(strings.length > 1) {
                    if (!strings[1].isEmpty())
                        strings[1] = strings[1].trim();
                }
                else
                    return false;

                /* SECOND PART of the file */
                scanner = new Scanner(strings[1]);

                while (scanner.hasNextLine()) {
                    Integer.parseInt(String.valueOf(scanner.nextInt()));
                    Integer.parseInt(String.valueOf(scanner.nextInt()));
                }

                scanner.close();
            }

            return true;
        }

        private Items checkItem(String value)
        {
            Items[] items = Items.values();

            for(Items item : items)
                if(Objects.equals(item.toString(), value))
                    return item;

            throw new UnknownFormatConversionException("Unknown value, requested an impossible conversion, a read value is probably bad written");
        }

        private void checkBoolean(String value)
        {
            if(value == null)
                throw new IllegalArgumentException("Null argument");

            /*
                // Seems to work only if boolean value is true

                if(!Boolean.parseBoolean(next))
                    throw new UnknownFormatConversionException("Unknown value, impossible convert a non boolean value to a boolean one");
            */

            if(!(value.equals("true") || value.equals("false")))
                throw new UnknownFormatConversionException("Unknown value, impossible convert " + "\"" + value + "\" to a boolean value");
        }

        private void checkWaterIndex(int index)
        {
            if(index < 0 || index >= componentWater.size())
                throw new ArrayIndexOutOfBoundsException("Given index is negative or higher than array size");
        }
        
        protected boolean contains(JCell cell)
        {
            for(RobotManiaWorldComponent component : listComponents)
            {
                if(component.getPositionX() == cell.getPositionX() && component.getPositionY() == cell.getPositionY())
                    return true;
            }

            return false;
        }
    }

    /* Getter and setter */

    /**
     * Getter of the map
     * @return Map of the game, a matrix of JCell if null return null
     * @view JCell
     */
    public JCell[][] getMap()
    {
        return map;
    }

    /**
     * Indicates if game is running in God mode or Fogged mode
     * @return boolean value
     * @view VersionSelector
     */
    public boolean getGameOption() {
        return fogOfWar;
    }

    /**
     *
     * @param dimension the dimension of the new map
     * @param new_game a boolean value, expressing if this is a new game o not (a loaded one)
     * @param optionGame If the new game is in God mode, or fogged one
     * @throws Exception
     *
     * @view VersionSelector
     */
    public void play(int dimension, boolean new_game, boolean optionGame) throws Exception
    {
        if(dimension <= 0)
            throw new IllegalArgumentException("Requested to play with a negative\neutral argument");

        RobotManiaModel.dimension = dimension;

        if(new_game)
        {
            // create components
            modelPlay.spawnComponents(dimension);

            // Initialise Array for households (componentsNotAlive)
            modelPlay.initializeWaterArray();

            // create map
            createMap(dimension, optionGame);
        }

        this.robot = modelPlay.getRobot();

        // now, each component has to get its position, and Icon on assigned cell
        assignPositionToComponents(modelPlay.getListComponents(), dimension, new_game);

        // check for water array
        // game could be loaded and every cell has to be checked.
        checkElementSpreadArray();
    }

    /**
     * Create a map of the game
     * @param dimension dimension for the matrix of JCell
     * @param optionGame If the new game is in God mode, or fogged one
     * @throws RuntimeException
     *
     * @view JCell Cell of the map
     * @view VersionSelector Selector for game version
     */
    public void createMap(int dimension, boolean optionGame) throws RuntimeException
    {    	
        this.fogOfWar = optionGame;

        if(dimension <= 0)
            throw new IllegalArgumentException("Impossible to create a map with negative or neutral parameter");

        this.map = new JCell[dimension][dimension];

        for(int i = 0; i < dimension; i++)
        {
            for (int j = 0; j < dimension; j++)
            {
                this.map[i][j] = new JCell(i,j);
                this.map[i][j].setBackgroundColor(optionGame);

                if(i == 0 || j == 0 || i == dimension - 1 || j == dimension -1)
                {
                    map[i][j].setItem(Items.WALL);

                    map[i][j].setFogOfWar(false);

                    map[i][j].setBackgroundColor(map[i][j].getWallColorCell());
                }
            }
        }
    }

    private void assignPositionToComponents(ArrayList<RobotManiaWorldComponent> listComponents, int dimension, boolean new_game) throws Exception {
        for(RobotManiaWorldComponent component : listComponents) {
            if(component.canLoadImages())
            {
                JCell cell;
                if(new_game)
                    cell = setComponentPosition(dimension);
                else
                    cell = new JCell(component.getPositionX(), component.getPositionY());


                setGraphicalNewPosition(component, cell.getPositionX(), cell.getPositionY());
            }
            else
                throw new Exception("Impossible load images about " + component.getItem() + "\nImpossible execute the program anymore");

        }
    }

    private JCell setComponentPosition(int dimension) throws RuntimeException
    {
        int tentative = 5;
        boolean ok = true;
        do
        {
            tentative--;
            JCell cell = setPosition(dimension);
            if(validatePosition(cell.getPositionX(), cell.getPositionY()))
                return cell;

            if(tentative == 0)
                ok = false;
        }while(ok);

        return forceSpawn(dimension);
    }

    private void setGraphicalNewPosition(RobotManiaWorldComponent component, int x, int y) throws RuntimeException
    {
        if(component.getItem().equals(Items.ROBOT))
            removeFogOfWar(x, y);

        this.map[x][y].setItem(component.getItem());

        // if the cell is not being discovered yet, I must not see what's there
        if(!this.map[x][y].isFogOfWar())
        {
            this.map[x][y].setIcon(component.getImageIcon());
            this.map[x][y].setBackgroundColor(this.map[x][y].getEmptyColorCell());
        }
        component.setPosition(x, y);
    }

    private JCell forceSpawn(int dimension) throws RuntimeException
    {
        for(int i = 1; i < dimension - 1; i++)
            for(int j = 1; j < dimension - 1; j++)
                if(validatePosition(i,j))
                    return new JCell(i,j);

        throw new RuntimeException("Impossible force to spawn, all cell full");
    }

    private JCell setPosition(int dimension)
    {
        int x, y;

        x = (int) Math.round(1 +  (Math.random() * (dimension - 2)));
        y = (int) Math.round(1 +  (Math.random() * (dimension - 2)));


        if(x == 2)
            x -= 1;

        if(y == 2)
            y -= 1;

        if(x == dimension - 2)
            x += 1;

        if(y ==  dimension - 2)
            y += 1;

        return this.map[x][y];
    }

    private boolean validatePosition(int x, int y)
    {
        return this.map[x][y].getItem() == Items.EMPTY;
    }

    /**
     * For each RobotManiaComponentAlive make a movement each time Robot make a movement
     * @return if Robot successfully moved in an empty JCell
     * @throws Exception
     *
     * @view RobotManiaComponentAlive
     * @view Robot
     * @view JCell
     */
    public boolean move_items() throws Exception
    {
        boolean ok = false;

        for(RobotManiaComponentAlive componentAlive : modelPlay.getComponentsAlive())
        {
            int x = componentAlive.getPositionX();
            int y = componentAlive.getPositionY();

            Directions direction = componentAlive.getNewDirection();

            if(direction == null)
            	throw new RuntimeException("RuntimeException: Receveid direction is null, impossible to move components " + componentAlive.getItem());
            
            if(isValidMove(x, y, direction))
                doMovement(componentAlive, x, y, direction);
            else
                if(componentAlive.getItem() == Items.ROBOT)
                    ok = true;
        }

        return ok;
    }

    private void removeElement(int indexCounter) throws RuntimeException
    {
        JCell cell = new JCell(0,0);
        Set<Water> array = new HashSet<>(modelPlay.getComponentWater(indexCounter));

        for (Water water : array) {
            int x = water.getPositionX();
            int y = water.getPositionY();

            if(this.map[x][y].isFogOfWar())
                this.map[x][y].setBackgroundColor(cell.getFogOfWarColorCell());
            else
                this.map[x][y].setBackgroundColor(this.map[x][y].isFogOfWar());

        }

        modelPlay.clearWaterArray(indexCounter);

        /*
            Now that the proper array is being emptied, other array have stored water
            So, there can be common cell that are now cleaned that shall be wet because of other array
            for that reason it's important to check it and remake visible
         */
        checkElementSpreadArray();
    }

    private void checkElementSpreadArray()
    {
        for(int i = 0; i < modelPlay.componentWaterSize(); i++)
            checkArray(modelPlay.getComponentWater(i));
    }

    // P.S: Se volessi aggiungere del fuoco, mi basterebbe mettere una variabile booleana, per differenziare tra fuoco e acqua.
    @SuppressWarnings("unchecked")
	private void generateElementSpread(int positionX, int positionY, int index, Integer...value) throws Exception
    {
        // case A: value is null
        if(value.length == 0)
        {
            if (modelPlay.getComponentWater(index).isEmpty())
                generate(positionX, positionY, index, true);
            else
                generateElementSpread((Set<Water>) modelPlay.getComponentWater(index).clone(), index);
        }


        // case B: value has a value
        if(value.length > 0)
        {
            if(value[0] == 0)
                return;

            // value[0] == 1
            generate(positionX, positionY, index, true);

            if(value[0] > 1)
            {
                do {
                    generateElementSpread((Set<Water>) modelPlay.getComponentWater(index).clone(), index);
                } while (modelPlay.getComponentWater(index).size() != value[0]);

            }
        }

        // Any case, check for array
        checkArray(modelPlay.getComponentWater(index));
    }

    private void generateElementSpread(Set<Water> waterCells, int index) throws Exception
    {
        for (Water water : waterCells)
            generate(water.getPositionX(), water.getPositionY(), index, false);
    }

    private void checkArray(HashSet<Water> componentWater)
    {
        JCell cell = new JCell(0,0);

        for(SpreadableElement element : componentWater) {
            if (!this.map[element.getPositionX()][element.getPositionY()].isFogOfWar())
                this.map[element.getPositionX()][element.getPositionY()].setBackgroundColor(cell.getWetColorCell());

            if(this.map[element.getPositionX()][element.getPositionY()].getItem().equals(Items.EMPTY) || this.map[element.getPositionX()][element.getPositionY()].getItem().equals(Items.WALL))
                this.map[element.getPositionX()][element.getPositionY()].setItem(Items.WET);
        }
    }
    
    private void generate(int x, int y, int index, boolean b) throws Exception
    {
        if(b)
            // same position of household
            modelPlay.addElementWater(x, y, index);
        else {
            // SOUTH
            if (isSpreadable(x + 1, y, index))
                modelPlay.addElementWater(x + 1, y, index);

            // NORTH
            if (isSpreadable(x - 1, y, index))
                modelPlay.addElementWater(x - 1, y, index);

            // RIGHT
            if (isSpreadable(x, y + 1, index))
                modelPlay.addElementWater(x, y + 1, index);

            // LEFT
            if (isSpreadable(x , y - 1, index))
                modelPlay.addElementWater(x, y - 1, index);
        }
    }

    private boolean isSpreadable(int x, int y, int index) throws Exception
    {
    	if(map[x][y] == null)
    		throw new Exception("Cell " + x + y + "is null");
    	
        if(!modelPlay.containsWater(x, y, index))
            return map[x][y].getItem() != Items.WALL;

        return false;
    }


    private boolean isValidMove(int positionX, int positionY, Directions direction) throws Exception
    {
        if(map == null)
            throw new Exception("Map is null");

        switch (direction)
        {
            case UP:
                return (positionX - 1 != 0) && (isWalkable(this.map[positionX - 1][positionY].getItem()));

            case DOWN:
                return (positionX + 1 != dimension - 1) && (isWalkable(this.map[positionX + 1][positionY].getItem()));

            case LEFT:
                return (positionY - 1 != 0) && (isWalkable(this.map[positionX][positionY - 1].getItem()));

            case RIGHT:
                return (positionY + 1 != dimension - 1) && (isWalkable(this.map[positionX][positionY + 1].getItem()));

            case NONE: return true;

            default:
                throw new IllegalArgumentException("Received direction doesn't exist");
        }
    }

    private boolean isWalkable(Items item)
    {
        return item == Items.EMPTY || item == Items.WET;
    }

    private void doMovement(RobotManiaComponentAlive component, int positionX, int positionY, Directions direction) throws RuntimeException
    {
        switch(direction)
        {
            case UP: component.setPosition(positionX - 1, positionY);
                break;

            case DOWN: component.setPosition(positionX + 1, positionY);
                break;

            case LEFT: component.setPosition(positionX, positionY - 1);
                break;

            case RIGHT: component.setPosition(positionX, positionY + 1);
                break;

            default:
                component.setPosition(positionX, positionY);
                break;
        }

        /*
             Now item have new position, but still have to update it graphically:
                - clean actual position
                - set new position
                - fog of war is removed, must check all water.
         */
        clean_position(positionX, positionY);
        setGraphicalNewPosition(component, component.getPositionX(), component.getPositionY());

        // Check water array
        checkElementSpreadArray();
    }

    private void clean_position(int oldX, int oldY)
    {
        JCell cell = this.map[oldX][oldY];

        if(cell.getItem() != Items.EMPTY)
            cell.setItem(Items.EMPTY);

        cell.setIcon(null);

        if(!cell.isFogOfWar())
            if(!cell.getColor().equals(cell.getWetColorCell()))
                cell.setBackgroundColor(cell.getEmptyColorCell());
    }

    /**
     * Each time Robot is required to make a movement, he gets a String of Directions and Items
     * looking in all Directions (UP, DOWNS, UP-LEFT, DOWN-RIGHT, etc...)
     *
     * @return String
     * @throws RuntimeException if robot is null or if JCell is null
     *
     * @view Robot
     * @view Directions
     * @view Items
     * @view JCell
     */
    public String getNeighbours() throws RuntimeException
    {
    	if(robot == null)
    		throw new RuntimeException("Robot is null");
    		
        int x = robot.getPositionX();
        int y = robot.getPositionY();

        String[] myString = {"UP-LEFT", "UP", "UP-RIGHT", "RIGHT", "DOWN-RIGHT", "DOWN", "DOWN-LEFT", "LEFT", "ACTUAL"};
        StringBuilder text = new StringBuilder();

        for (String s : myString)
        {
            switch (s)
            {
                case "UP-LEFT":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x - 1, y - 1));
                    break;

                case "UP":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x - 1, y));
                    break;

                case "UP-RIGHT":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x - 1, y + 1));
                    break;

                case "RIGHT":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x, y + 1));
                    break;

                case "DOWN-RIGHT":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x + 1, y + 1));
                    break;

                case "DOWN":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x + 1, y));
                    break;

                case "DOWN-LEFT":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x + 1, y - 1));
                    break;

                case "LEFT":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x, y - 1));
                    break;

                case "ACTUAL":
                    text.append("[").append(s).append("] = ").append(getNeighbour(x, y));
            }


            text.append("\n");
        }

        return text.toString();
    }

    private String getNeighbour(int x, int y) throws RuntimeException
    {
        JCell cell = this.map[x][y];

        Items item = cell.getItem();
        switch(item)
        {
            case DOG: return "DOG";
            case CAT: return "CAT";

            case ROBOT:
                if(cell.getColor().equals(cell.getWetColorCell()))
                    return "WET CELL";
                else
                    return "EMPTY CELL";

            case EMPTY: return "EMPTY CELL";

            case WALL: return "WALL";

            case STOVE:
            case SINK:
            case WASHING_MACHINE:
            {
                if(cell.getStatus())
                    return item + " ON";
                else
                    return item.toString();
            }

            case WET: return "WET CELL";
        }

        throw new IllegalArgumentException("Received item doesn't exists");
    }

    /**
     * In fogged mode, there will be a limited range of view for robot, and each move he can discover new JCell
     * @param newX X position closer to Robot
     * @param newY Y position closer to Robot
     * @throws RuntimeException
     *
     * @view Robot
     * @view JCell
     */
    public void removeFogOfWar(int newX, int newY) throws RuntimeException
    {
    	if(map == null)
    		throw new RuntimeException("Map is null, must be generated before");
    	
        removeFogWarCell(newX - 1, newY - 1);
        removeFogWarCell(newX + 1, newY + 1);
        removeFogWarCell(newX, newY - 1);
        removeFogWarCell(newX, newY + 1);
        removeFogWarCell(newX + 1, newY);
        removeFogWarCell(newX - 1, newY);
        removeFogWarCell(newX + 1, newY - 1);
        removeFogWarCell(newX - 1, newY + 1);
        removeFogWarCell(newX, newY);
    }

    private void removeFogWarCell(int x, int y) throws RuntimeException
    {
    	if(map[x][y] == null)
    		throw new RuntimeException("A cell of the map is null");
    	
        // remove fog of War, if there's
        if(this.map[x][y].isFogOfWar()) {
            this.map[x][y].setBackgroundColor(false);

            // Household do not show when robot walks, so I need to check if in cell there's a household
            if(!this.map[x][y].getItem().equals(Items.EMPTY)) {
                for (RobotManiaComponentNotAlive componentNotAlive : modelPlay.getComponentsNotAlive())
                    if (componentNotAlive.getPositionX() == x && componentNotAlive.getPositionY() == y)
                        this.map[x][y].setIcon(componentNotAlive.getImageIcon());
            }
        }
    }

    /**
     * Makes Robot turns left or right
     * @param turnDirection class Directions, accepted parameters are Directions.TURN_LEFT and Directions.TURN_RIGHT
     * @throws RuntimeException
     *
     * @view Directions
     * @view Robot
     */
    public void turnRobot(Directions turnDirection) throws RuntimeException
    {
    	if(turnDirection == null)
    		throw new IllegalArgumentException("Null argument");
    	
    	if(robot == null)
    		throw new IllegalArgumentException("Robot is null");
    	    	
        if(turnDirection == Directions.TURN_LEFT)
            robot.setImageIcon(robot.turnLeft());
        else if(turnDirection == Directions.TURN_RIGHT)
            robot.setImageIcon(robot.turnRight());
        else
        	throw new IllegalArgumentException("Receveid Directions doesn't exists");

    	if(this.map[robot.getPositionX()][robot.getPositionY()] == null)
    		throw new RuntimeException("Cell where Robot is placed is null");
    	
        this.map[robot.getPositionX()][robot.getPositionY()].setIcon(robot.getImageIcon());
    }

    /**
     * Action may fail, Robot can't walk thorugh household or wall or pet
     * @param code RobotManiaModel.MOVE or RobotManiaModel.ACTION
     * @return String of error contained in given code, if code doesn't exist return empty String
     * @throws RuntimeException if code is null
     */
    public String getBUMP(String code) throws RuntimeException
    {
    	if(code == null)
    		throw new IllegalArgumentException("Null argument");
    	
        switch(code)
        {
            case "move": return "BUMP: Impossible to move there";
            case "action": return "BUMP: No Household detected";

            default: return "";
        }
    }

    /**
     * When Robot is in front of Household can turn them off
     * @return boolean value, indicates if action is successfully or not
     * @throws RuntimeException if Robot is null or given cell is inaccessible
     */
    public boolean makeAction() throws RuntimeException
    {
    	if(robot == null)
    		throw new RuntimeException("Robot is null");
    	
    	if(map == null)
    		throw new RuntimeException("Map is null, map must be generated before");
    	
    	
        int x = robot.getPositionX(), y = robot.getPositionY();

        switch(robot.getNewDirection())
        {
            case UP: return defineObject(x - 1, y);

            case DOWN: return defineObject(x + 1, y);

            case LEFT: return defineObject(x, y - 1);

            case RIGHT: return defineObject(x, y + 1);

            default: return false;
        }
    }

    private boolean defineObject(int x, int y) throws RuntimeException
    {
        int index = 0;

        for(RobotManiaComponentNotAlive componentNotAlive : this.modelPlay.getComponentsNotAlive())
        {
            if (componentNotAlive.getPositionX() == x && componentNotAlive.getPositionY() == y) {
                this.map[componentNotAlive.getPositionX()][componentNotAlive.getPositionY()].setStatus(false);
                componentNotAlive.setStatus(false);
                componentNotAlive.setImageIcon(componentNotAlive.getPair(false));

                componentNotAlive.setCountdown((int) Math.round(4 + (Math.random() * (dimension * 2))));

                // Household is being fixed, remove water or just change image, only if cell hasn't "Fog of war"
                if(!this.map[componentNotAlive.getPositionX()][componentNotAlive.getPositionY()].isFogOfWar())
                    this.map[componentNotAlive.getPositionX()][componentNotAlive.getPositionY()].setIcon(componentNotAlive.getImageIcon());

                if (componentNotAlive.getElement().equals(Element.WATER_SPREAD))
                    removeElement(index);

                return true;
            }
            index++;
        }

        return false;
    }

    /**
     * Given a string and lines of that string load game, only if String doesn't' match with game standards
     * @param readFile String of the loading game
     * @param countLines Integer number of lines of the String
     * @throws Exception If readFile doesn't' match game standard
     *
     */
    public void loadGame(String readFile, int countLines) throws Exception {

        /* Check the file, if is correct to execute it */
        boolean res = modelPlay.isValidFile(readFile,countLines);

        if(!res)
            throw new Exception("File doesn't match with rule game standards");

        String[] strings = readFile.split("SECOND_PART");
        Scanner scanner = new Scanner(strings[0]);
        Scanner scanner2 = new Scanner(strings[1]);

        int dimension = scanner.nextInt();
        boolean gameOption = scanner.nextBoolean();

        createMap(dimension, gameOption);

        while(scanner.hasNext())
        {
            int x = scanner.nextInt();
            int y = scanner.nextInt();

            if(x >= dimension || y >= dimension)
                throw new Exception("Pair of value " + x + " " + y + " in file bigger than dimension " + dimension);

            Items item = Items.valueOf(scanner.next());
            boolean fogOfWar = Boolean.parseBoolean(scanner.next());
            boolean status = Boolean.parseBoolean(scanner.next());

            int index = 0;
            if(item.equals(Items.SINK) || item.equals(Items.WASHING_MACHINE) || item.equals(Items.STOVE))
            {
                // legge un indice dalla seconda parte in ordine, e lo attribuisce al componente
                if(scanner2.hasNext())
                {
                    index = scanner2.nextInt();
                    scanner2.nextInt();
                }
            }

            /*
                Controllo le posizioni, se non sono occupate:
                nel caso avessi manualmente modificato da file le posizioni dei componenti,
                mettendo in stesse celle 2 o piu' componenti
             */
            JCell cell = new JCell(0,0);

            if(item != Items.EMPTY && item != Items.WET)
                cell = makeCorrection(x,y, modelPlay.getListComponents());

            if(cell.getPositionX() == 0 && cell.getPositionY() == 0)
                modelPlay.addComponent(x, y, item, index, status);
            else
                modelPlay.addComponent(cell.getPositionX(), cell.getPositionY(), item, index, status);

            this.map[x][y].setBackgroundColor(fogOfWar);
        }
        
        scanner.close();
        scanner2.close();

        // Water array initialize
        modelPlay.initializeWaterArray();

        Scanner scanner3 = new Scanner(strings[1]);

        while(scanner3.hasNext())
        {
            int index = scanner3.nextInt();
            int watermills = scanner3.nextInt();

            if(watermills != 0)
                generateElementSpread(modelPlay.getComponentsNotAlive().get(index).getPositionX(), modelPlay.getComponentsNotAlive().get(index).getPositionY(), index, watermills);
        }
        
        scanner3.close();
    }

    private JCell makeCorrection(int x, int y, ArrayList<RobotManiaWorldComponent> listComponents) throws RuntimeException
    {
        JCell theCell = new JCell(0,0);

        for(RobotManiaWorldComponent component : listComponents)
        {
            if(component.getPositionX() == x && component.getPositionY() == y)
            {
                theCell = getValidPosition();

                if(theCell == null)
                    throw new RuntimeException("Impossible find another free cell on map");

                return theCell;
            }
        }

        return theCell;
    }

    private JCell getValidPosition() throws RuntimeException
    {
        int tentative = 8;

        // random position
        do {
            JCell cell = setComponentPosition(map.length);

            if (!modelPlay.contains(cell))
                return cell;

            tentative--;

        } while (tentative != 0);

        return null;
    }

    /**
     * Save game from own map
     * @return String contenting saved game
     * @throws RuntimeException if JCell is null
     *
     * @view JCell
     */
    public String saveGame() throws RuntimeException
    {
    	if(map == null)
    		throw new RuntimeException("Impossible save Game, the map is null");
    	
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<JCell> cells = new ArrayList<>();

        // Write the map dimension and the map Game option (with or without Fog Of War)
        stringBuilder.append(this.map.length).append("\n").append(this.fogOfWar);

        for(JCell[] rows : this.map)
        {
            for(JCell cell : rows)
            {
                if(!(cell.getItem().equals(Items.WALL)))
                {
                    if (cell.getItem().equals(Items.SINK) || cell.getItem().equals(Items.STOVE) || cell.getItem().equals(Items.WASHING_MACHINE))
                        cells.add(cell);
                    else {
                        if(cell.getItem().equals(Items.EMPTY) || cell.getItem().equals(Items.WET)) {
                            if(fogOfWar && !cell.isFogOfWar())
                                stringBuilder.append("\n").append(cell.getPositionX()).append(" ").append(cell.getPositionY()).append(" ").append(cell.getItem()).append(" ").append(cell.isFogOfWar()).append(" ").append(cell.getStatus());
                        }
                        else {
                            stringBuilder.append("\n").append(cell.getPositionX()).append(" ").append(cell.getPositionY()).append(" ").append(cell.getItem()).append(" ").append(cell.isFogOfWar()).append(" ").append(cell.getStatus());
                        }
                    }
                }
            }
        }

        StringBuilder secondStringBuilder = new StringBuilder();

        // Ordering the print of household
        for(RobotManiaComponentNotAlive componentNotAlive : modelPlay.getComponentsNotAlive())
        {
            for(JCell cell : cells)
            {
                if(componentNotAlive.getPositionX() == cell.getPositionX() && componentNotAlive.getPositionY() == cell.getPositionY())
                    stringBuilder.append("\n").append(cell.getPositionX()).append(" ").append(cell.getPositionY()).append(" ").append(cell.getItem()).append(" ").append(cell.isFogOfWar()).append(" ").append(cell.getStatus());
            }

            secondStringBuilder.append("\n").append(componentNotAlive.getIndex()).append(" ").append(modelPlay.getComponentWater(componentNotAlive.getIndex()).size());
        }

        stringBuilder.append("\nSECOND_PART");
        stringBuilder.append(secondStringBuilder);

        return stringBuilder.toString();

    }

    /**
     * Each household has a own counter before breaking themselves and start spreading water
     * If counter equals 0, it turns on the household
     */
    public void decreaseHouseHoldsCounter()
    {
        for(RobotManiaComponentNotAlive componentNotAlive : modelPlay.getComponentsNotAlive()) {
            if (componentNotAlive.getCountdown() == 0)
            {
                componentNotAlive.setStatus(true);
                this.map[componentNotAlive.getPositionX()][componentNotAlive.getPositionY()].setStatus(true);

                turnOnStatus(componentNotAlive, componentNotAlive.getPositionX(), componentNotAlive.getPositionY(), componentNotAlive.isStatus());
            } else {
                componentNotAlive.decreaseCountdown();
            }
        }
    }

    private void turnOnStatus(RobotManiaComponentNotAlive componentNotAlive, int x, int y, boolean status)
    {
        componentNotAlive.setImageIcon(componentNotAlive.getPair(status));

        if(!this.map[x][y].isFogOfWar())
            this.map[x][y].setIcon(componentNotAlive.getImageIcon());
    }

    /**
     * Spread SpreadableElement from household
     * @throws Exception
     * @view SpreadableElement
     */
    public void spreadElements() throws Exception
    {	
        int indexCounter = 0;
        for(RobotManiaComponentNotAlive componentNotAlive : modelPlay.getComponentsNotAlive())
        {
            int x = componentNotAlive.getPositionX();
            int y = componentNotAlive.getPositionY();

            if(componentNotAlive.isStatus() && componentNotAlive.getElement().equals(Element.WATER_SPREAD)) {
                    if (componentNotAlive.getSpreadElementSpeed() == 0) {
                        generateElementSpread(x, y, indexCounter);

                        componentNotAlive.setSpreadElementSpeed(componentNotAlive.getItem());
                    } else
                        componentNotAlive.decreaseCounterSpread();
            }

            indexCounter ++;
        }
    }
}