package components.pet;

import components.RobotManiaComponentAlive;
import enum_folder.Directions;
import enum_folder.Items;

import java.util.HashMap;
import java.util.Map;

public abstract class DomesticPet extends RobotManiaComponentAlive
{
    private final Map<Integer, Directions> dict;

    /**
     * DomesticPet, include Cat and Dog
     * @param item
     *
     * @view Cat
     * @view Dog
     */
    public DomesticPet(Items item)
    {
        super();

        setItem(item);
        this.dict = createDictionary();
    }

	private Map<Integer, Directions> createDictionary()
    {
        Map<Integer, Directions> dict = new HashMap<>();
        dict.put(0, Directions.UP);
        dict.put(1, Directions.LEFT);
        dict.put(2, Directions.RIGHT);
        dict.put(3, Directions.DOWN);
        dict.put(4, Directions.NONE);

        return dict;
    }

    /**
     * Random value based on that, DomesticPet will get his new Directions
     * @return Directions of the RobotManiaComponentAlive
     *
     * @view Directions
     * @view RobotManiaComponentAlive
     */
    public Directions getNewDirection()
    {
        int x = (int) Math.round(Math.random() * (dict.size() - 1) );
        return dict.get(x);
    }
    public abstract void loadImages();
}
