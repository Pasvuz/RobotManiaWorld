package components.pet;

import enum_folder.Items;

import javax.swing.*;
import java.util.Objects;

public class Cat extends DomesticPet
{
    /**
     * Cat constructor
     * Subclass of DomesticPet
     *
     * @view DomesticPet
     */
    public Cat()
    {
        super(Items.CAT);
        loadImages();
    }

    /**
     * LoadImages of the cat
     */
    @Override
    public void loadImages() {
        try
        {
            setImageIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/pet/cat.png"))));
            setCanLoadImages(true);
        }
        catch(Exception e)
        {
            setCanLoadImages(false);
        }
    }
}
