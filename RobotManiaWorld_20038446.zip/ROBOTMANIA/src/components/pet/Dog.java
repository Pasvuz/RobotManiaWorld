package components.pet;

import enum_folder.Items;

import javax.swing.*;
import java.util.Objects;

public class Dog extends DomesticPet
{
    /**
     * Dog constructor
     * Subclass of DomesticPet
     *
     * @view DomesticPet
     */
    public Dog()
    {
        super(Items.DOG);
        loadImages();
    }

    /**
     * load images of the Dog
     */
    @Override
    public void loadImages() {
        try
        {
            setImageIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/pet/dog.png"))));
            setCanLoadImages(true);
        }
        catch(Exception e)
        {
            setCanLoadImages(false);
        }
    }
}
