package components.waterFire_Element;

import components.RobotManiaComponentNotAlive;
import enum_folder.Element;
import enum_folder.Items;

import javax.swing.*;
import java.util.Objects;

public class Sink extends RobotManiaComponentNotAlive
{
    /**
     * Sink constructor
     *
     * subclass of RobotManiaComponentNotAlive
     *
     * @param index identification
     *
     * @view RobotManiaComponentNotAlive
     */
    public Sink(int index)
    {
        super(index);

        this.setSpreadElementSpeed(Items.SINK);
        loadImages();
        setImageIcon(getPair(isStatus()));
        setItem(Items.SINK);
        setElement(Element.WATER_SPREAD);
    }

    /**
     * load images of sink based on his status (on / off)
     */
    protected void loadImages() {
        try
        {
            addPair(false, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/water/sink.png"))));
            addPair(true, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/water/sink_water.png"))));
            setCanLoadImages(true);
        }
        catch(Exception e)
        {
            setCanLoadImages(false);
        }
    }
}
