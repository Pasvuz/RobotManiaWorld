package components.waterFire_Element;

public class Water extends SpreadableElement
{
    /**
     * Water constructor
     *
     * subclass of SpreadableElement
     * @param x x position in view map
     * @param y y position in view map
     */
    public Water(int x, int y)
    {
        super(x,y);
    }
}
