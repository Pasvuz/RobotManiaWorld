package components.waterFire_Element;

public class SpreadableElement
{
    private final int positionX;
    private final int positionY;

    /**
     * Superclass of Water and Fire
     * @param x x position in view map
     * @param y y position in view map
     *
     * @view Water
     * @view Fire
     */
    public SpreadableElement(int x, int y)
    {
        this.positionX = x;
        this.positionY = y;
    }

    /**
     * position X getter
     * @return position X
     */
    public int getPositionX() {
        return positionX;
    }

    /**
     * position Y getter
     * @return position Y
     */
    public int getPositionY() {
        return positionY;
    }
}
