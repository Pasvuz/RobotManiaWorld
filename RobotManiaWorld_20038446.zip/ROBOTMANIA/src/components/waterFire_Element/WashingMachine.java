package components.waterFire_Element;


import components.RobotManiaComponentNotAlive;
import enum_folder.Element;
import enum_folder.Items;

import javax.swing.*;
import java.util.Objects;

public class WashingMachine extends RobotManiaComponentNotAlive
{
    /**
     * Washing Machine constructor
     *
     * subclass of RobotManiaComponentNotAlive
     * @param index identification
     */
    public WashingMachine(int index) {
        super(index);

        setSpreadElementSpeed(Items.WASHING_MACHINE);
        loadImages();
        setImageIcon(getPair(isStatus()));
        setItem(Items.WASHING_MACHINE);
        setElement(Element.WATER_SPREAD);
    }

    /**
     * load images of stove based on his status (on / off)
     */
    @Override
    protected void loadImages() {
        // TODO controllare che le immagini siano davvero caricate e i valori non nulli, se così genera subito l'eccezione
        try
        {
            addPair(false, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/water/washing_machine.png"))));
            addPair(true, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/water/washing_machine_water.png"))));
            setCanLoadImages(true);
        }
        catch(Exception e)
        {
            setCanLoadImages(false);
        }
    }
}
