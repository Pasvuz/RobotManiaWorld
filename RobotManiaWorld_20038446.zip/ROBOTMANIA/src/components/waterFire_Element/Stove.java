package components.waterFire_Element;


import components.RobotManiaComponentNotAlive;
import enum_folder.Element;
import enum_folder.Items;

import javax.swing.*;
import java.util.Objects;

public class Stove extends RobotManiaComponentNotAlive
{
    /**
     * Stove constructor
     *
     * subclass of RobotManiaComponentNotAlive
     * @param index identification
     */
    public Stove(int index) {
        super(index);

        loadImages();
        setImageIcon(getPair(isStatus()));
        setItem(Items.STOVE);
        setElement(Element.FIRE_SPREAD);
    }

    /**
     * load images of stove based on his status (on / off)
     */
    @Override
    protected void loadImages() {
        try
        {
            addPair(false, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/fire/stove.png"))));
            addPair(true, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/fire/stove_fire.png"))));
            setCanLoadImages(true);
        }
        catch(Exception e)
        {
            setCanLoadImages(false);
        }
    }
}
