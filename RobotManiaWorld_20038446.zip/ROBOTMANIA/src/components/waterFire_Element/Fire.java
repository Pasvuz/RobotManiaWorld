package components.waterFire_Element;

public class Fire extends SpreadableElement
{
    /**
     * Fire Constructor
     *
     * NOT IMPLEMENTED IN GAME
     *
     * Subclass of SpreadableElement
     *
     * @param x
     * @param y
     * @view SpreadableElement
     */
    public Fire(int x, int y) {
        super(x, y);
    }
}
