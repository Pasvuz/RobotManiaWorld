package components.robot;


import components.RobotManiaComponentAlive;
import enum_folder.AngleView;
import enum_folder.Directions;
import enum_folder.Items;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Robot extends RobotManiaComponentAlive
{
    private AngleView angleView;
    private final Map<Directions, ImageIcon> dict;

    /**
     * Robot constructor
     * subclass of the RobotManiaComponentAlive
     *
     * @view RobotManiaComponentAlive
     */
    public Robot()
    {
        super();

        this.angleView = AngleView.UP;
        this.dict = new HashMap<>();

        loadImages();
        setImageIcon(dict.get(Directions.UP));
        setItem(Items.ROBOT);
    }

    /**
     * Load images based on the angle of the Robot
     *
     * @view AngleView
     */
    protected void loadImages()
    {
        try
        {
            dict.put(Directions.UP, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/robot/robot_up.png"))));
            dict.put(Directions.DOWN, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/robot/robot_down.png"))));
            dict.put(Directions.LEFT, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/robot/robot_left.png"))));
            dict.put(Directions.RIGHT, new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/robot/robot_right.png"))));

            setCanLoadImages(true);
        }
        catch (Exception e)
        {
            setCanLoadImages(false);
        }
    }

    /**
     * Robot will turn left on his position
     *
     * @return Image of new angle view
     *
     * @view AngleView
     */
    public ImageIcon turnLeft()
    {
        return this.dict.get(fix(angleView.getValue() + 90));
    }

    /**
     * Robot will turn right on his position
     *
     * @return Image of new angle view
     *
     * @view AngleView
     */
    public ImageIcon turnRight()
    {
        return this.dict.get(fix(angleView.getValue() - 90));
    }

    private Directions fix(Integer angle)
    {
        if(angle < 0)
            angle = 270;

        if(angle >= 360)
            angle = 0;

        angleView = AngleView.fromInteger(angle);
        return getNewDirection();
    }

    /**
     * Based on his angle, return new Direction
     * @return Directions Robot looking Directions
     *
     * @view AngleView
     */
    public Directions getNewDirection()
    {
        switch (this.angleView)
        {
            case UP: return Directions.UP;
            case LEFT: return Directions.LEFT;
            case RIGHT: return Directions.RIGHT;
            case DOWN: return Directions.DOWN;
        }

        throw new IllegalArgumentException("No direction has been detected");
    }
}