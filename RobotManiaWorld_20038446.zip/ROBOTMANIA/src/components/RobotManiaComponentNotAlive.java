package components;

import enum_folder.Element;
import enum_folder.Items;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

public abstract class RobotManiaComponentNotAlive extends RobotManiaWorldComponent
{
    private final int INDEX;

    private final int WASHING_MACHINE_TURNS = 6;
    private final int SINK_TURNS = 9;

    private boolean status;
    private Element element;
    private Map<Boolean, ImageIcon> dict;
    private int countdown;
    private int spreadElementSpeed;

    /**
     * Abstract class for all Households
     * @param index identification
     *
     * @view Sink
     * @view Stove
     * @view WashingMachine
     */
    public RobotManiaComponentNotAlive(int index) {
        super();

        this.dict = new HashMap<>();
        status = false;

        this.INDEX = index;

        if(index < 2)
            setCountdown((int) ((Math.random() * (index + 10) + 7)));
        else
            setCountdown((int) ((Math.random() * (index + 5)) + 3));
    }

    /* GETTER AND SETTER */

    /**
     * Get index
     * @return integer value of identification
     */
    public int getIndex() {
        return INDEX;
    }

    /**
     * household status getter
     * @return boolean, true (=on) otherwise off
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * Set new status replacing precedent one
     * @param status boolean
     */
    public void setStatus(boolean status) {
        this.status = status;
    }

    /**
     * If household is Water element or Fire one
     * @return Element
     *
     * @view Element
     */
    public Element getElement() {
        return element;
    }

    protected void setElement(Element element) {
        if(element == null)
            throw new IllegalArgumentException("Null argument");

        this.element = element;
    }


    protected void addPair(Boolean key, ImageIcon value)
    {
        if(key != null && value != null)
            this.dict.put(key, value);
    }

    /**
     * Given the status return the image
     * @param key boolean
     * @return ImageIcon image of household
     */
    public ImageIcon getPair(Boolean key)
    {
        if(key != null)
            return dict.get(key);

        throw new IllegalArgumentException("Null argument");
    }

    /**
     * Set new countdown for household
     * @param random_number
     */
    public void setCountdown(int random_number) {
        this.countdown = (int) Math.round(1 + (Math.random() * random_number));
    }

    /**
     * return countdown
     * @return integer
     */
    public int getCountdown() {
        return countdown;
    }

    /**
     * Decrease by one the countdown
     */
    public void decreaseCountdown()
    {
        countdown -= 1;
    }

    /**
     * return how much fast is household to spread Element
     * @return integer
     */
    public int getSpreadElementSpeed() {
        return spreadElementSpeed;
    }

    /**
     * restore turn for household to spread ElementSpreadable
     * @param item household item
     */
    public void setSpreadElementSpeed(Items item)
    {
        switch(item)
        {
            case SINK:
                spreadElementSpeed = SINK_TURNS;
                break;

            case WASHING_MACHINE:
                spreadElementSpeed = WASHING_MACHINE_TURNS;
                break;

            case STOVE:
                spreadElementSpeed = 0;

            default: break;
        }
    }

    /**
     * Decrease counter spread
     */
    public void decreaseCounterSpread()
    {
        spreadElementSpeed -= 1;
    }
}
