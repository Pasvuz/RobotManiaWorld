package components;

import enum_folder.Directions;

public abstract class RobotManiaComponentAlive extends RobotManiaWorldComponent
{
    /**
     * An abstract class, includes all Component that are able to move
     * subclass of RobotManiaWorldComponent
     *
     * @view DomesticPet
     * @view Robot
     */
    public RobotManiaComponentAlive()
    {
        super();
    }

    public abstract Directions getNewDirection();

}
