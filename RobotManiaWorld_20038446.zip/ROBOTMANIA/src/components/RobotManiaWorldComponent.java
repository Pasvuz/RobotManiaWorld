package components;

import enum_folder.Items;
import javax.swing.*;

public abstract class RobotManiaWorldComponent
{
    private int positionX;
    private int positionY;
    private ImageIcon imageIcon;
    private Items item;
    private boolean canLoadImages;

    /**
     * Abstract class
     * Create component
     */
    protected RobotManiaWorldComponent() {
    }

    /**
     * Get Component position X
     * @return
     */
    public int getPositionX() {
        return positionX;
    }

    /**
     * Set Component position
     * @param positionX X position
     * @param positionY Y position
     */
    public void setPosition(int positionX, int positionY)
    {
        setPositionX(positionX);
        setPositionY(positionY);
    }

    /**
     * Set item of Component
     * @param item Items
     *
     * @view Items
     */
    public void setItem(Items item) {
        if(item != null)
            this.item = item;
    }

    /**
     * Return Item of Component
     * @return Items
     *
     * @view Items
     */
    public Items getItem() {
        return item;
    }

    private void setPositionX(int positionX) {
        this.positionX = positionX;
    }

    /**
     * Get Component position Y
     * @return
     */
    public int getPositionY() {
        return positionY;
    }

    private void setPositionY(int positionY) {
        this.positionY = positionY;
    }

    /**
     * Get Component image
     * @return ImageIcon
     */
    public ImageIcon getImageIcon() {
        return this.imageIcon;
    }

    /**
     * Set new Image to Component
     * @param imageIcon
     */
    public void setImageIcon(ImageIcon imageIcon) {
        if(imageIcon != null)
            this.imageIcon = imageIcon;
    }


    protected void setCanLoadImages(boolean value)
    {
        this.canLoadImages = value;
    }

    /**
     * return if Component can load images
     * Checking if any of them is null
     * @return
     */
    public boolean canLoadImages()
    {
        return this.canLoadImages;
    }

    protected abstract void loadImages();
}
