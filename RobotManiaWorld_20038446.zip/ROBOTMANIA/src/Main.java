import controller.RobotManiaController;
import model.RobotManiaModel;
import view.JoystickViewer;
import view.RobotManiaView;

import javax.swing.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class Main {

    private static PropertyChangeListener listener;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
                () ->
                {
                    listener = new PropertyChangeListener() {
                        @Override
                        public void propertyChange(PropertyChangeEvent evt) {
                            if(evt.getPropertyName().equals("close"))
                                System.exit(0);
                        }
                    };

                    JoystickViewer joystickViewer = new JoystickViewer();
                    RobotManiaModel model = new RobotManiaModel();
                    RobotManiaView view = new RobotManiaView();
                    RobotManiaController controller = new RobotManiaController(model, view, joystickViewer);
                    controller.manageListener(listener);
                }
        );
    }
}
