package controller;

import customMessages.GenerateMessage;
import enum_folder.Directions;
import model.RobotManiaModel;
import view.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.MissingResourceException;

public class RobotManiaController
{
    private final int DIMENSION = 9;
    private final RobotManiaView view;
    private final RobotManiaModel model;
    private final JoystickViewer joystick;

    /**
     * Constructor RobotManiaController, the controller for RobotManiaWorld
     *
     * @param model RobotManiaModel the model of the game
     * @param view  RobotManiaView  the view of the game, what user sees
     * @param joystick JoystickViewer joystick, the interface thanks to user can control Robot in game
     *
     * @view RobotManiaModel
     * @view RobotManiaView
     * @view JoystickViewer
     */
    public RobotManiaController(RobotManiaModel model, RobotManiaView view, JoystickViewer joystick)
    {
        if(model == null || view == null || joystick == null)
            throw new IllegalArgumentException("Given a null argument");

        this.model = model;
        this.view = view;
        this.joystick = joystick;

        try {
            model.createMap(DIMENSION, false);
            view.setNewMap(model.getMap());
        }
        catch (Exception e){
            new GenerateMessage(e.getMessage(), GenerateMessage.ERROR);
            System.exit(1);

        }
        new GenerateMessage(true);
    }

    private void close(PropertyChangeListener listener)
    {
        GenerateMessage gm = new GenerateMessage();
        int option = gm.askConfirm();
        if (option == 1) {
            view.close();
            joystick.close();
            listener.propertyChange(new PropertyChangeEvent(this, "close", 1, 0));
        }
    }

    /**
     * Manage every button Listener looking at RobotManiaView and JoystickViewer instances
     * @param listener An instance of PropertyChangeListener
     * @view PropertyChangeListener
     *
     * @view PropertyChangeListener
     * @view RobotManiaView
     * @view JoystickViewer
     */
    public void manageListener(PropertyChangeListener listener)
    {
        if(listener == null)
            throw new IllegalArgumentException("PropertyChangeListener parameter is not being uninitialized");

        this.view.getView().addWindowListener(
                new WindowAdapter() {
                    @Override
                    public void windowOpened(WindowEvent e) {
                        super.windowOpened(e);
                    }

                    @Override
                    public void windowClosing(WindowEvent e) {
                        close(listener);
                        super.windowClosing(e);
                    }

                    @Override
                    public void windowClosed(WindowEvent e) {
                        super.windowClosed(e);
                    }

                    @Override
                    public void windowIconified(WindowEvent e) {
                        super.windowIconified(e);
                    }

                    @Override
                    public void windowDeiconified(WindowEvent e) {
                        super.windowDeiconified(e);
                    }

                    @Override
                    public void windowActivated(WindowEvent e) {
                        super.windowActivated(e);
                    }

                    @Override
                    public void windowDeactivated(WindowEvent e) {
                        super.windowDeactivated(e);
                    }

                    @Override
                    public void windowStateChanged(WindowEvent e) {
                        super.windowStateChanged(e);
                    }

                    @Override
                    public void windowGainedFocus(WindowEvent e) {
                        super.windowGainedFocus(e);
                    }

                    @Override
                    public void windowLostFocus(WindowEvent e) {
                        super.windowLostFocus(e);
                    }
                }
        );

        this.view.getControlView().get_btnPlay().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    VersionSelector versionSelector = new VersionSelector();
                    boolean detectedGame = versionSelector.getClickedVersion();

                    play(true, detectedGame);
                    joystick.addText_to_txtInfo(model.getNeighbours());

                } catch(Exception exception) {
                    new GenerateMessage(exception.getMessage(), GenerateMessage.ERROR);
                    System.exit(1);

                }
            }
        });

        this.view.getControlView().get_btnChangeDimension().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                UserDimensionChoiceView userDimension = new UserDimensionChoiceView(6);
                try {
                    model.createMap(userDimension.getDimensionValue(), false);
                    view.setNewMap(model.getMap());
                }
                catch (Exception exception)
                {
                    new GenerateMessage(exception.getMessage(), GenerateMessage.ERROR);
                    System.exit(1);

                }
            }
        });

        this.view.getControlView().get_btnLoadGame().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                FileManager fileManager = new FileManager(true, null);

                if(fileManager.getFileText() != null && fileManager.getCountLines() > 0)
                {
                    try
                    {
                        model.loadGame(fileManager.getFileText(), fileManager.getCountLines());
                        play(false, model.getGameOption());
                    }
                    catch (Exception illegalArgumentException)
                    {
                        new GenerateMessage(illegalArgumentException.getMessage(), GenerateMessage.ERROR);
                        System.exit(1);
                    }
                }
            }
        });

        /* JOYSTICK */
        joystick.getBtnUp().addActionListener(e -> {
            //joystick.disableButtons();

            try
            {
                // Move items, if Robot create error, launch message on joystick
                if(model.move_items())
                    joystick.addText_to_txtConsole(model.getBUMP(RobotManiaModel.MOVE));

                // Decrease by one all counter of households
                model.decreaseHouseHoldsCounter();

                // Spread Water / Fire from household
                model.spreadElements();

                joystick.addText_to_txtInfo(model.getNeighbours());

            } catch (Exception ex) {
                new GenerateMessage(ex.getMessage(), GenerateMessage.ERROR);
                System.exit(1);
            }

            view.setNewMap(model.getMap());

            //joystick.enableButtons();
        });

        joystick.getBtnTurnRight().addActionListener(
        			e -> turnRobot(Directions.TURN_RIGHT)
        );

        joystick.getBtnTurnLeft().addActionListener(
                e -> turnRobot(Directions.TURN_LEFT)
        );

        joystick.getBtnAction().addActionListener(
                /*
                    Check if in Robot Direction there is something to interact with, is fo, do something
                    otherwise BUMP
                 */
                e -> {
                    try {
                        if(!model.makeAction())
                            joystick.addText_to_txtConsole(model.getBUMP(RobotManiaModel.ACTION));


                        joystick.addText_to_txtInfo(model.getNeighbours());
                    } catch (Exception ex) {
                        new GenerateMessage(ex.getMessage(), GenerateMessage.ERROR);
                        System.exit(1);
                    }
                }
        );

        joystick.getBtnInfo().addActionListener(
                e -> new GenerateMessage(true)
        );

        joystick.getBtnSaveGame().addActionListener(
            e -> {

                try
                {
                    FileManager fileManager = new FileManager(false, model.saveGame());
                    if(fileManager.isWroteSuccessfully())
                        new GenerateMessage("Game successfully created!", GenerateMessage.PLAIN);
                    else
                        new GenerateMessage("Something wrong meanwhile saving game", GenerateMessage.ERROR);
                }
                catch (Exception exception)
                {
                    new GenerateMessage(exception.getMessage(), GenerateMessage.ERROR);
                    System.exit(1);

                }

            }
        );

        joystick.getBtnClose().addActionListener(
                e -> close(listener)
        );
    }

    private void turnRobot(Directions direction) {
    	try {
			model.turnRobot(direction);
		} catch (Exception e) {
			new GenerateMessage(e.getMessage(), GenerateMessage.ERROR);
            System.exit(1);

        }
	}

	private void play(boolean new_game, boolean optionGame) throws Exception {
        this.view.closeControlView();

        this.model.play(this.view.getDimension(), new_game, optionGame);
        this.view.setNewMap(this.model.getMap());
        if(this.joystick.ifCanWork())
            joystick.show_window();
        else
            throw new MissingResourceException("Joystick Images impossible to load, impossible to go on", "RobotManiaController", "0");
    }
}
