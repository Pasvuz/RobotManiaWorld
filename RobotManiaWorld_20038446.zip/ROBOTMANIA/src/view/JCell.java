package view;

import enum_folder.Items;

import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class JCell extends JLabel
{
    private final Color waterCell = Color.CYAN;
    private final Color wallCell = Color.BLACK;
    private final Color emptyCell = Color.WHITE;
    private final Color fogOfWarCell = Color.LIGHT_GRAY;

    private final int X_POSITION;
    private final int Y_POSITION;
    private Items item;
    private boolean status;
    private boolean fogOfWar;
    private Color color;

    /**
     * JCell
     *
     * subclass of JLabel
     * @param x x position
     * @param y y position
     */
    public JCell(int x, int y)
    {
        this.X_POSITION = x;
        this.Y_POSITION = y;

        setOpaque(true);
        setBorder(BorderFactory.createLineBorder(Color.RED, 1));
        setItem(Items.EMPTY);
    }

    /**
     * Get X
     * @return int X position
     */
    public int getPositionX() {
        return X_POSITION;
    }

    /**
     * Get Y
     * @return int y position
     */
    public int getPositionY() {
        return Y_POSITION;
    }

    /**
     * Get Item of JCell
     * @return Items
     *
     * @view Items
     */
    public Items getItem() {
        return item;
    }

    /**
     * Set Item on JCell
     * @param item
     *
     * @view Items
     */
    public void setItem(Items item) {
    	if(item != null)
    		this.item = item;
    }

    /**
     * Return if JCell has fog of War
     * @return boolean
     */
    public boolean isFogOfWar() {
        return fogOfWar;
    }

    /**
     * Set fog of War
     * @param fogOfWar
     */
    public void setFogOfWar(boolean fogOfWar)
    {
        this.fogOfWar = fogOfWar;
    }

    /**
     * Based on fog of war value, set new fog of war and get is color beased on that
     * @param fogOfWar
     */
    public void setBackgroundColor(boolean fogOfWar)
    {
        setFogOfWar(fogOfWar);

        if(fogOfWar)
            setBackgroundColor(fogOfWarCell);
        else
            setBackgroundColor(emptyCell);
    }

    /**
     * Given a color it sets is color
     * @param color
     */
    public void setBackgroundColor(Color color)
    {
        this.color = color;
        this.setBackground(color);
    }

    /**
     * Get WET Color Cell
     * @return Color
     *
     * @view Color
     */
    public Color getWetColorCell()
    {
        return waterCell;
    }

    /**
     * Get Fog Of War Color Cell
     * @return Color
     *
     * @view Color
     */
    public Color getFogOfWarColorCell()
    {
        return fogOfWarCell;
    }

    /**
     * Get Empty Color Cell
     * @return Color
     *
     * @view Color
     */
    public Color getEmptyColorCell()
    {
        return emptyCell;
    }

    /**
     * Get Wall Color Cell
     * @return Color
     *
     * @view Color
     */
    public Color getWallColorCell() {
        return wallCell;
    }

    /**
     * Get actual Color of JCell
     * @return Color
     *
     * @view Color
     */
    public Color getColor()
    {
        return this.color;
    }

    /**
     * Get status of JCell
     * @return boolean
     */
    public boolean getStatus() {
        return status;
    }

    /**
     * Set status of JCell
     * @param status
     */
    public void setStatus(boolean status) {
        this.status = status;
    }
}