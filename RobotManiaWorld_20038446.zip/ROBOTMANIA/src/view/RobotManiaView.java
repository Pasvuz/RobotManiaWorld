package view;


import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class RobotManiaView extends JFrame
{
    private final GridBagConstraints gridBagConstraints;
    private MapView mapView;
    private ControlView controlView;

    /**
     * Main view component for RobotManiaWorld
     */
    public RobotManiaView()
    {
        this.gridBagConstraints = new GridBagConstraints();

        this.initializeComponents();
        this.setVisible(true);
    }

    private void initializeComponents()
    {
        this.setTitle("RobotMania World 20038446");
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setSize(800, 600);
        this.setMinimumSize(this.getSize());
        this.setLayout(new GridBagLayout());

        this.mapView = new MapView();
        this.controlView = new ControlView();

        addMapView(gridBagConstraints);
        addControlView(gridBagConstraints);
    }

    /**
     * Return itself in case for Window Listener
     * @return
     */
    public JFrame getView()
    {
        return this;
    }

    /**
     * Get ControlView
     * @return ControlView
     *
     * @view ControlView
     */
    public ControlView getControlView() {
        return controlView;
    }

    /**
     * close COntrol View, giving more space to other components
     */
    public void closeControlView()
    {
        this.remove(controlView);

        validate();
    }

    /**
     * Gets mapview dimension
     * @return
     */
    public int getDimension()
    {
        return this.mapView.getDimension();
    }

    /**
     * Set new map in MapView
     * @param map
     */
    public void setNewMap(JCell[][] map)
    {
        if(map == null)
            throw new IllegalArgumentException("Null argument");

        this.remove(mapView);
        this.mapView.replace(map);
        addMapView(gridBagConstraints);

        validate();
    }

    /**
     * Close the entire view
     */
    public void close()
    {
        this.dispose();
    }
    
    private void addMapView(GridBagConstraints gridBagConstraints) {
        gridBagConstraints.weightx = 1;
        gridBagConstraints.weighty = 3;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = GridBagConstraints.BOTH;

        this.add(this.mapView, gridBagConstraints);
    }

    private void addControlView(GridBagConstraints gridBagConstraints) {
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.weighty = 0.3;
        gridBagConstraints.fill = GridBagConstraints.BOTH;

        this.add(this.controlView, gridBagConstraints);
    }
}