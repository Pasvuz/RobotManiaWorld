package view;

import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class MapView extends JPanel
{
    private int dimension;

    /**
     * MapView contains the map
     */
    public MapView()
    {
    	dimension = 0;
    }

    /**
     * Given a new map it will replace it
     * If null nothing happen
     * @param map matrix of JCell
     *
     * @view JCell
     */
    public void replace(JCell[][] map)
    {
        dimension = map.length;
        this.setLayout(new GridLayout(dimension, dimension, 2, 2));

        // remove everything
        this.removeAll();

        // add new map
        for(int i = 0; i < dimension; i++)
            for(int j = 0; j < dimension; j++)
                this.add(map[i][j]);
    }

    /**
     * Gives map dimension
     * @return
     */
    public int getDimension() {
        return dimension;
    }
}