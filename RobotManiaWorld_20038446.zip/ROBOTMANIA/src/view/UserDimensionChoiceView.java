package view;

import customMessages.GenerateMessage;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.util.Objects;

@SuppressWarnings("serial")
public class UserDimensionChoiceView extends JDialog {
    // There is needed a lot of space for all components and have space to move around
    private final int minDimensionTable;
    private final int maxDimensionTable = 25;
    private int inputDimension = -1;  //if no input, value will be that, otherwise will change

    /**
     * UserDimensionChoiceView
     * An input GUI for Input value
     * @param minDimensionTable minimum value admitted
     */
    public UserDimensionChoiceView(Integer minDimensionTable)
    {
        this.minDimensionTable = minDimensionTable;
        this.initiateComponents();
        this.close();
    }

    /**
     * Get input dimension
     * @return Integer input dimension
     */
    public Integer getDimensionValue()
    {
        return inputDimension;
    }

    /**
     * Close view
     */
    public void close()
    {
        this.dispose();
    }

    private void initiateComponents()
    {
        this.setTitle("Notification");
        this.setAlwaysOnTop(true);
        this.setModalityType(ModalityType.APPLICATION_MODAL);
        this.getContentPane().setLayout(null);
        this.setSize(500,200);
        this.setResizable(false);
        this.setBackground(Color.gray);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lInfo = new JLabel("<html>Check if you want to input dimension yourself<br />Then click button</html>");
        lInfo.setBounds(15, 15, 400, 60);
        lInfo.setFont(new Font("Calibre", Font.PLAIN, 17));

        JCheckBox cbBoolean = new JCheckBox();
        cbBoolean.setBounds(420,15, 50,50);

        JTextField tNumber = new JTextField("Insert here number, only number admitted!");
        tNumber.setVisible(false);
        tNumber.setBounds(15, 70, 350, 40);
        tNumber.setFont(new Font(Font.SERIF, 12, 15));

        JButton bWarning = new JButton();
        bWarning.setVisible(false);
        try
        {
            Image img = ImageIO.read(Objects.requireNonNull(getClass().getResource("/image/info.png")));

            bWarning.setIcon(new ImageIcon(img));
            bWarning.setBounds(370, 70, 40, 40);
        }
        catch(Exception e)
        {
            bWarning.setText("Read!");
            bWarning.setBounds(370, 70, 75, 40);
        }

        bWarning.addActionListener(e -> new GenerateMessage
                ("<html>Imputable minimum number is " + minDimensionTable + "<br />Is necessary a lot of space for all components and have space to work properly<br />input >= " + minDimensionTable + ", max is 25</html>", GenerateMessage.INFO)
        );

        JButton bConfirmation = new JButton("Confirm choice");
        bConfirmation.setBounds(this.getWidth() / 2 - this.getWidth() / 8, this.getHeight() / 2 + this.getHeight() / 8, 125, 30);

        bConfirmation.addActionListener(e -> {
            if(cbBoolean.isSelected())
            {
                if(!tNumber.isVisible())
                {
                    tNumber.setVisible(true);
                    bWarning.setVisible(true);
                    bConfirmation.setText("Reconfirm");
                }
                else if(checkInput(tNumber.getText()) < minDimensionTable && inputDimension >= maxDimensionTable)
                {
                    AlertUser();
                    tNumber.setText("6");
                }
                else
                    this.dispose();
            }
            else
                this.dispose();

        });

        this.add(lInfo);
        this.add(cbBoolean);
        this.add(tNumber);
        this.add(bWarning);
        this.add(bConfirmation);
        this.setVisible(true);
    }
    
    private Integer checkInput(String text)
    {
        if(text != null)
        {
            try
            {
                int x = Integer.parseInt(text);
                inputDimension = x;
                return x;
            }
            catch (Exception e)
            {
                return -1;
            }
        }

        return -1;
    }

    private void AlertUser()
    {
        new GenerateMessage("<html>- Only number are expected, no text<br />- Number greater than " + minDimensionTable + "</html>", "error");
    }
}
