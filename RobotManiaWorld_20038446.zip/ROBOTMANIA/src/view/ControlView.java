package view;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

@SuppressWarnings("serial")
public class ControlView extends JPanel
{
	private final MyButton btnPlay;
    private final MyButton btnLoadGame;
    private final MyButton btnChangeDimension;
    private final PropertyChangeSupport support;

    /**
     * ControlView has the 3 main button in loading game
     */
    public ControlView() {
        super(new GridBagLayout());
        this.btnPlay = new MyButton("Play");
        this.btnChangeDimension = new MyButton("Change dimension");
        this.btnLoadGame = new MyButton("Load game");
        this.support = new PropertyChangeSupport(this);

        this.initializeView();
    }

    static class MyButton extends JButton {
        public MyButton(String name) {
            super(name);
            this.setBackground(Color.darkGray);
            this.setForeground(Color.green);
            this.setOpaque(true);
            this.setFocusable(false);
            this.setFont(new Font("Monospace", Font.BOLD, 20));
        }
    }

    /**
     * Add property listener, used when window has to close
     * @param listener  the PropertyChangeListener to be added
     *
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        this.support.addPropertyChangeListener(listener);
    }

    private void initializeView() {
        GridBagConstraints gridBag = new GridBagConstraints();

        gridBag.weightx = 0.5;
        gridBag.weighty = 0.5;
        gridBag.gridx = 0;
        gridBag.gridy = 0;
        gridBag.fill = GridBagConstraints.BOTH;
        this.add(this.btnPlay, gridBag);

        gridBag.gridx = 0;
        gridBag.gridy = 1;
        gridBag.fill = GridBagConstraints.BOTH;
        this.add(this.btnChangeDimension, gridBag);

        gridBag.gridx = 0;
        gridBag.gridy = 2;
        gridBag.fill = GridBagConstraints.BOTH;
        this.add(this.btnLoadGame, gridBag);
    }

    /**
     * Get button play
     * @return JButton play
     */
    public JButton get_btnPlay() {
        return this.btnPlay;
    }

    /**
     * Get button Load Game
     * @return JButton game
     */
    public JButton get_btnLoadGame() {
        return this.btnLoadGame;
    }

    /**
     * Get button ChangeDimension
     * @return JButton ChangeDimension
     */
    public JButton get_btnChangeDimension() {
        return this.btnChangeDimension;
    }
}

