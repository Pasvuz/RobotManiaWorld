package view;

import customMessages.GenerateMessage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

@SuppressWarnings("serial")
public class VersionSelector extends JDialog
{
    private JLabel textClear;
    private JLabel textFogged;
    private boolean clicked;

    /**
     * VersionSelector
     *
     * Given two option it will give User opportunity to choose between them
     */
    public VersionSelector()
    {
        initializeComponent();
    }

    /**
     * Get the version selected
     * @return
     */
    public boolean getClickedVersion() {
        return clicked;
    }

    private void initializeComponent()
    {
        this.setModalityType(ModalityType.APPLICATION_MODAL);
        this.setSize(600, 150);
        this.setMinimumSize(this.getSize());
        this.setLayout(new BorderLayout());

        this.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {
                new GenerateMessage("Choose the version of the game, the chosen will be the colored one.\nDefault one is God mode\n\nClose GUI for confirm version", GenerateMessage.INFO);
            }

            @Override
            public void windowClosing(WindowEvent e) {
                new GenerateMessage("Chosen version: " + printVersion(), GenerateMessage.INFO);
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });

        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.clicked = false;

        this.textClear = new JLabel("<html>You will clearly see each cell of the map <br />when some changes happen, and if something broke</html>");

        this.textFogged = new JLabel("<html>You will have to explore the map<br /> once discovered you will be able to see clearly<br /> what's happening in cell where Robot was</html>");

        JButton button = new JButton("Click for switch color");

        JPanel panel1 = new JPanel(new FlowLayout());
        panel1.setBorder(BorderFactory.createTitledBorder("God mode"));
        panel1.add(textClear);


        JPanel panel2 = new JPanel(new FlowLayout());
        panel2.setBorder(BorderFactory.createTitledBorder("Fogged mode"));
        panel2.add(textFogged);

        this.add(panel1, BorderLayout.EAST);
        this.add(panel2, BorderLayout.WEST);

        this.add(button, BorderLayout.SOUTH);
        button.addActionListener(
                e -> changeColor()
        );

        this.setVisible(true);
    }

    private void changeColor()
    {
        if(this.clicked)
        {
            clicked = false;
            /*
                Clear version
             */
            textFogged.setForeground(Color.BLACK);
            textClear.setForeground(Color.orange);
        }
        else
        {
            clicked = true;
            /*
                Fogged version
             */
            textFogged.setForeground(Color.pink);
            textClear.setForeground(Color.BLACK);
        }
    }

    private String printVersion()
    {
        return (clicked) ? "Fogged mode" : "God mode";
    }
}
