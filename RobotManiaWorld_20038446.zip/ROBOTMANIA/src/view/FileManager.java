package view;

import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class FileManager
{
    private String fileText;
    private int countLines;
    private boolean writeSuccessfully;

    /**
     * File Manager constructor
     * @param operation if true will read, otherwise write
     * @param text The message that you want to write
     */
    public FileManager(boolean operation, String text)
    {
        countLines = 0;
        fileText = "";
        writeSuccessfully = false;

        if(operation)
            read();
        else
            write(text);
    }

    /**
     * After read File Manager will store the read string
     * @return the readen string
     */
    public String getFileText() {
        return fileText;
    }

    /**
     * Lines of readen string
     * @return integer text lines
     */
    public int getCountLines() {
        return countLines;
    }

    /**
     * During write operation something can go wrong
     * @return boolean value, if successfully managed to write
     */
    public boolean isWroteSuccessfully() {
        return writeSuccessfully;
    }

    private String analyze(File file)
    {
        StringBuilder dataBuilder = new StringBuilder();

        if(file == null)
            throw new IllegalArgumentException("Null argument");

        try {
            if (file.canRead())
            {
                Scanner myReader = new Scanner(file);
                while (myReader.hasNextLine()) {
                    dataBuilder.append(myReader.nextLine()).append("\n");
                    countLines++;
                }
                myReader.close();
            }

            return dataBuilder.toString();
        }
        catch (IOException exception)
        {
            return "";
        }
    }

    /**
     * Read method
     * The readen content is obtainable with "getFileText()"
     */
    public void read()
    {
        /* Classe interna al metodo */

        @SuppressWarnings("serial")
        class FileChooser extends JFrame
        {
            private File file;
            public FileChooser()
            {
                initializeComponent();
            }

            public File getFile() {
                return file;
            }

            private void initializeComponent()
            {
                JFileChooser fileChooser = new JFileChooser();
                int res = fileChooser.showOpenDialog(null);

                if (res == JFileChooser.APPROVE_OPTION)
                {
                    file = fileChooser.getSelectedFile();
                }

                if(res == JFileChooser.CANCEL_OPTION)
                    file = null;

                this.add(fileChooser);
                this.setVisible(true);
            }
        }

        /*
            Wait for a file to read
        */
        FileChooser fileChooser = new FileChooser();
        String data = analyze(fileChooser.getFile());

        if (!data.isEmpty())
            fileText = data;
        else
            fileText = null;
    }

    /**
     * Write method
     * Whatever it happens, he will not generate Exception, check for isWroteSuccessfully for result
     * @param fileText the string to write
     */
    public void write(String fileText)
    {
        if(fileText != null)
        {
            File file = new File(getNameFile() + ".txt");

            writeSuccessfully = writeFile(fileText, file);
        }
        else
            writeSuccessfully = false;
    }

    private boolean writeFile(String fileText, File file)
    {
        try {
            FileWriter fileWriter = new FileWriter(file, false);

            fileWriter.append(fileText);

            fileWriter.close();
            return true;
        } catch (Exception e)
        {
            System.out.println("ERROR: " + e.getMessage());
            return false;
        }

    }

    private String getNameFile()
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy_MM_dd");
        LocalDateTime now = LocalDateTime.now();

        return dtf.format(now);
    }
}
