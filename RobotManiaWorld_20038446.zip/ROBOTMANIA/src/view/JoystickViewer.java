package view;

import javax.swing.*;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;

@SuppressWarnings("serial")
public class JoystickViewer extends JFrame
{
    private boolean canWork;
    private JButton btnUp;
    private JButton btnTurnLeft;
    private JButton btnTurnRight;
    private JButton btnAction;
    private JButton btnInfo;
    private JButton btnSaveGame;
    private JButton btnClose;
    private JTextArea txtInfo;
    private int rowsTxtConsole;
    private JTextArea txtConsole;

    /**
     * JoystickViewer constructor, print on GUI a joystick
     */
    public JoystickViewer()
    {
        initializeComponent();
    }

    /**
     * joystick is on default hidden, this for show it up
     */
    public void show_window()
    {
        this.setVisible(true);
    }

    /* Getter and setter */

    /**
     * Get Btn Up
     * @return JButton
     *
     * @viewe JButton
     */
    public JButton getBtnUp() {
        return btnUp;
    }

    /**
     * Get Btn Turn Left
     * @return JButton
     *
     * @view JButton
     */
    public JButton getBtnTurnLeft() {
        return btnTurnLeft;
    }

    /**
     * Get Btn Turn Right
     * @return JButton
     *
     * @view JButton
     */
    public JButton getBtnTurnRight() {
        return btnTurnRight;
    }

    /**
     * Get Btn Make Action
     * @return JButton
     *
     * @view JButton
     */
    public JButton getBtnAction() {
        return btnAction;
    }

    /**
     * Get Info Button
     * @return JButton
     *
     * @view JButton
     */
    public JButton getBtnInfo() {
        return btnInfo;
    }

    /**
     * Get Save Game btn
     * @return JButton
     *
     * @view JButton
     */
    public JButton getBtnSaveGame() {
        return btnSaveGame;
    }

    /**
     * Get Shutdown button
     * @return JButton
     *
     * @view JButton
     */
    public JButton getBtnClose() {
        return btnClose;
    }

    /**
     * Tell if joystick work
     * @return
     */
    public boolean ifCanWork() {
        return canWork;
    }

    private void initializeComponent()
    {
        this.setAlwaysOnTop(true);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setTitle("Joystick");
        this.setResizable(false);
        this.setSize(440,300);
        this.setLayout(null);
        this.canWork = true;

        Queue<ImageIcon> queue = new LinkedList<>();
        try
        {
            queue.add(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/joystick/frecciaUp.png"))));
            queue.add(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/joystick/frecciaTurnLeft.png"))));
            queue.add(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/joystick/frecciaTurnRight.png"))));
            queue.add(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/info.png"))));
            queue.add(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/joystick/save_file.png"))));
            queue.add(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/shutdown.png"))));
        }
        catch (Exception e) {
            canWork = false;
            return;
        }

        this.btnUp = new JButton(queue.remove());
        this.btnUp.setBounds(320, 10, 45,45);

        this.btnTurnLeft = new JButton(queue.remove());
        this.btnTurnLeft.setBounds(270, 10, 45,45);

        this.btnTurnRight = new JButton(queue.remove());
        this.btnTurnRight.setBounds(370, 10, 45,45);

        this.btnAction = new JButton("Execute action");
        this.btnAction.setBounds(270, 60, 145, 45);

        this.btnInfo = new JButton(queue.remove());
        this.btnInfo.setBounds(270, 180,45,45);

        this.btnSaveGame = new JButton(queue.remove());
        this.btnSaveGame.setBounds(320, 180, 45,45);

        this.btnClose = new JButton(queue.remove());
        this.btnClose.setBounds(370, 180, 45,45);

        this.txtInfo = new JTextArea();
        this.txtInfo.setBounds(10,10, 240,160);
        this.txtInfo.setBorder(BorderFactory.createTitledBorder("Cell Information"));
        this.txtInfo.setEditable(false);

        this.txtConsole = new JTextArea();
        this.txtConsole.setBounds(10, 170, 240, 80);
        this.txtConsole.setBorder(BorderFactory.createTitledBorder("Movement Status"));
        this.txtConsole.setEditable(false);

        this.add(this.txtInfo);
        this.add(this.txtConsole);
        this.add(this.btnUp);
        this.add(this.btnTurnLeft);
        this.add(this.btnTurnRight);
        this.add(this.btnAction);
        this.add(this.btnClose);
        this.add(this.btnInfo);
        this.add(this.btnSaveGame);
    }

    /**
     * Add text to JTextArea
     *
     * Each time is cleaned from past content
     * @param text
     * @view JTextArea
     */
    public void addText_to_txtInfo(String text)
    {
        if(text == null)
            return;

        // delete
        this.txtInfo.setText("");
        // write
        this.txtInfo.append(text + "\n");
    }

    /**
     * Add text to JTextArea
     *
     * Each 3 string it will be resetted to clean
     * @param texto
     *
     * @view JTextArea
     */
    public void addText_to_txtConsole(String texto)
    {
        if(texto == null)
            return;

        this.rowsTxtConsole++;
        if(rowsTxtConsole == 3)
        {
            this.txtConsole.setText("");
            this.rowsTxtConsole = 0;
        }

        this.txtConsole.append(texto + "\n");
    }

    /**
     * Close JoystickView
     */
    public void close()
    {
        this.dispose();
    }

    /*
    public void enableButtons()
    {
        btnUp.setEnabled(true);
        btnTurnLeft.setEnabled(true);
        btnTurnRight.setEnabled(true);
        btnAction.setEnabled(true);
        btnSaveGame.setEnabled(true);
    }

    public void disableButtons()
    {
        btnUp.setEnabled(false);
        btnTurnLeft.setEnabled(false);
        btnTurnRight.setEnabled(false);
        btnAction.setEnabled(false);
        btnSaveGame.setEnabled(false);
    }
    */
}
